print('Hello CodeSentinel')
